var express = require('express');
var router = express.Router();
//var Todo = require('../models/crud');
var mongoose = require('mongoose');
//var app = express();
var Todo = mongoose.model('Todo', {
    task: {
        type: String,
        required: true
    }
});
//_______________________________________________________BEGIN Read ( render ) todos to home page 
router.get('/', function(req, res) {
//alert(1111);
    Todo.find(function(err, arrayOfItems) {
        res.render('index', {
            todos: arrayOfItems
        });
    });
});
//_______________________________________________________END Read ( render ) todos to home page
//_______________________________________________________BEGIN Create todo and update page
router.post('/', function(req, res) {  
    var todo = new Todo({
        task: req.body.task
    }).save(function(err) {
        Todo.find(function(err, toHBS) {
            todos: toHBS
        });
        return res.redirect('/crud/');
    });
});
router.get('/edit/:id/', function(req, res) {
    var id = req.params.id;
    Todo.findOne({
        _id: id
    }, function(err, doc) {
        res.render('edit', {
            todos: doc
        });
    });
})
router.post('/update/:id', function(req, res) {
    var id = req.params.id;
    Todo.findById(id, function(err, todo) {
        todo.task = req.body.updated_task
        todo.save();
        return res.redirect('/crud/');
    });
})
//_______________________________________________________END Update todo

//_______________________________________________________BEGIN Delete todo and update the page
router.get('/delete/:id', function(req, res) {
    Todo.findById(req.params.id, function(err, todo) {   
        if (!err) {
            todo.remove();
        } else {
            return err
        }
    });
    return res.redirect('/crud/');
})

module.exports = router;