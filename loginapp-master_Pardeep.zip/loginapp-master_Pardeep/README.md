# Node.js Loginapp

This is a user login and registration app using Node.js, Express, Passport and Mongoose. 

### Version
1.1.0

### Usage


### Installation

To run-

```sh
$ npm install
```

```sh
$ npm start
```