var mongoose = require('mongoose');

// User Schema
 module.exports.Todo = mongoose.model('Todo', {
    task: {
        type: String,
        required: true
    }
})

//var Todo = module.exports = mongoose.model('User', Todo);
//_______________________________________________________END setup


//_______________________________________________________END Delete todo and update the page










