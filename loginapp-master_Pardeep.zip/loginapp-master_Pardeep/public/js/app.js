$(function() {

    $("#todo-field").focus();
})